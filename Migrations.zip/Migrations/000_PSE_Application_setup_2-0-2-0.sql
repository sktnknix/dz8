UPDATE 
	APPLICATION_SETUP
SET
	application_patch = '2.0',
	application_version = '2.0'