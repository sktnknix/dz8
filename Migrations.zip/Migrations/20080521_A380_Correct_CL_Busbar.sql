update T_CHOICELIST
set choicevalue = '400PP/703PP/705PP'
where ChoiceList = 'Busbar'
and choicevalue like '%400PP/703PP/705PP'


update T_CHOICELIST
set choicevalue = '400PP/7PP3'
where ChoiceList = 'Busbar'
and choicevalue like '%400PP/7PP3'