update
	infobase
set
	object_name ='ELA Enveloppe'
where
	object_value='ELA_Enveloppe'
	and table_name='R_FIN_DS'