								--------------------------------------------------------------
								-- AFDX INT									        	--
								-- SS: ELCODATA_V1.30_synthesis_sheet_AFDXAttribute.doc	--
								--------------------------------------------------------------


UPDATE T_SSPC_VL
SET SSPC_VL_AfdxFallBackStatusInt = SSPC_VL_AfdxFallBackStatus
FROM T_SSPC_VL