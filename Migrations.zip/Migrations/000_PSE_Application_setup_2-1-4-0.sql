UPDATE 
	APPLICATION_SETUP
SET
	application_patch = '4.0',
	application_version = '2.1'