delete 
from
	T_choicelist
where 
	choicelist = 'FINCategory'
	and choicevalue = 'LRI SOFTWARE'

delete 
from
	T_choicelist
where 
	choicelist = 'FINCategory'
	and choicevalue = 'MULTI-LOADING SW'