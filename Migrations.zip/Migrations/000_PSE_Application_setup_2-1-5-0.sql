UPDATE 
	APPLICATION_SETUP
SET
	application_patch = '5.0',
	application_version = '2.1'