delete t_infoversion 

insert into t_infoversion (Product,StartDate,Enddate,Version) VALUES('ELCODATA','02/07/2011',null,'4.1')
insert into t_infoversion (Product,StartDate,Enddate,Version) VALUES('ELCODATA','21/01/2011','02/07/2011','3.2')
insert into t_infoversion (Product,StartDate,Enddate,Version) VALUES('ELCODATA','22/01/2010','21/01/2011','3.0')
insert into t_infoversion (Product,StartDate,Enddate,Version) VALUES('PDMLINK','30/05/2011',null,'4.4.1 ')
insert into t_infoversion (Product,StartDate,Enddate,Version) VALUES('PDMLINK','21/01/2011','30/05/2011','4.4')
insert into t_infoversion (Product,StartDate,Enddate,Version) VALUES('PDMLINK','01/10/2009','21/01/2011','4.2')
insert into t_infoversion (Product,StartDate,Enddate,Version) VALUES('PSE','02/07/2011',null,'1.33')
insert into t_infoversion (Product,StartDate,Enddate,Version) VALUES('PSE','21/01/2011','02/07/2011','1.32')
insert into t_infoversion (Product,StartDate,Enddate,Version) VALUES('PSE','22/01/2010','21/01/2011','1.30')
insert into t_infoversion (Product,StartDate,Enddate,Version) VALUES('Stored Procedure','02/07/2011',null,'4.4')
insert into t_infoversion (Product,StartDate,Enddate,Version) VALUES('Stored Procedure','22/01/2010','02/07/2011','4.2')

