

update
	infobase
set
	list_val='A11;A12;A21;A22;B11;B12;B21;B22;C11;C12;C21;C22;D11;D12;D21;D22;G11;G12;G21;G22;H11;H12;H21;H22;I11;I12;I21;I22;J11;J12;J21;J22;S;T;N/A'
where
	object_value='GroupShedding'
	and table_name='r_fin_ds'

