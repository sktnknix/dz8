--------------------------------------------------------------------------------------
------------------------------ FIN DATA Migration ------------------------------------
--------------------------------------------------------------------------------------


UPDATE R_FIN_CI SET FinCIHWGroup='1501XZx'  where FIN = '1501XZ1'
UPDATE R_FIN_CI SET FinCIHWGroup='1501XZx'  where FIN = '1501XZ2'
UPDATE R_FIN_CI SET FinCIHWGroup='1501XZx'  where FIN = '1502XZ1'
UPDATE R_FIN_CI SET FinCIHWGroup='1501XZx'  where FIN = '1502XZ2'
UPDATE R_FIN_CI SET FinCIHWGroup='6QMx'  where FIN = '6QM1'
UPDATE R_FIN_CI SET FinCIHWGroup='6QMx'  where FIN = '6QM2'
UPDATE R_FIN_CI SET FinCIHWGroup='6QMx'  where FIN = '6QM3'
UPDATE R_FIN_CI SET FinCIHWGroup='921TFx'  where FIN = '9TF21'
UPDATE R_FIN_CI SET FinCIHWGroup='921TFx'  where FIN = '9TF24'
UPDATE R_FIN_CI SET FinCIHWGroup='922TFx'  where FIN = '9TF22'
UPDATE R_FIN_CI SET FinCIHWGroup='922TFx'  where FIN = '9TF23'
UPDATE R_FIN_CI SET FinCIHWGroup='971TFx'  where FIN = '9TF71'
UPDATE R_FIN_CI SET FinCIHWGroup='971TFx'  where FIN = '9TF72'
UPDATE R_FIN_CI SET FinCIHWGroup='1401XZx'  where FIN = '1402XZ1'
UPDATE R_FIN_CI SET FinCIHWGroup='1401XZx'  where FIN = '1402XZ2'
UPDATE R_FIN_CI SET FinCIHWGroup='2CVx'  where FIN = '2CV1'
UPDATE R_FIN_CI SET FinCIHWGroup='2CVx'  where FIN = '2CV2'
UPDATE R_FIN_CI SET FinCIHWGroup='NULL'  where FIN = '9TF51'
UPDATE R_FIN_CI SET FinCIHWGroup='201HXx'  where FIN = '202HX'
UPDATE R_FIN_CI SET FinCIHWGroup='201HWx'  where FIN = '201HW2'
UPDATE R_FIN_CI SET FinCIHWGroup='201HWx'  where FIN = '202HW2'
UPDATE R_FIN_CI SET FinCIHWGroup='NULL'  where FIN = '201HW'
UPDATE R_FIN_CI SET FinCIHWGroup='NULL'  where FIN = '202HW'












