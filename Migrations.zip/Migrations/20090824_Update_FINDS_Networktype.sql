
update
	r_fin_ds
set	
	FINDS_NetworkType='Normal'
where
eddreference like '2452XPAC000005%'
or eddreference like '2452XPAC000010%'
or eddreference like '3073DWAC000005%'
or eddreference like '3073DWAC000006%'
or eddreference like '3073DWAC000007%'
or eddreference like '3073DWAC000008%'
or eddreference like '3436RTAC000001%'
or eddreference like '2328RVAC000002%'
or eddreference like '3436RTAC000002%'
or eddreference like '2722CYDC000002%'
or eddreference like '3073DWDC000001%'
or eddreference like '3073DWDC000002%'
or eddreference like '3073DWDC000004%'
or eddreference like '3520WRAC000012%'
