delete t_infoversion 

insert into t_infoversion (Product,StartDate,Enddate,Version) VALUES('ELCODATA','02/07/2011',null,'4.2')
insert into t_infoversion (Product,StartDate,Enddate,Version) VALUES('ELCODATA','21/01/2011','02/07/2011','3.2')
insert into t_infoversion (Product,StartDate,Enddate,Version) VALUES('ELCODATA','22/01/2010','21/01/2011','3.0')
insert into t_infoversion (Product,StartDate,Enddate,Version) VALUES('PSE','02/07/2011',null,'1.33')
insert into t_infoversion (Product,StartDate,Enddate,Version) VALUES('PSE','21/01/2011','02/07/2011','1.32')
insert into t_infoversion (Product,StartDate,Enddate,Version) VALUES('PSE','22/01/2010','21/01/2011','1.30')
insert into t_infoversion (Product,StartDate,Enddate,Version) VALUES('SV','27/05/2011',null,'2.4.7')
insert into t_infoversion (Product,StartDate,Enddate,Version) VALUES('SV','05/11/2010','27/05/2011','2.4.6')
insert into t_infoversion (Product,StartDate,Enddate,Version) VALUES('SV','01/10/2009','05/11/2010','2.4.5')
