-- Delete FIN CI 5PH created twice
delete from r_fin_ci
where 0=0
and id_fin = 8790

